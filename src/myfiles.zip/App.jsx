import React, { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAngleRight } from "@fortawesome/free-solid-svg-icons";
import { series, movies, tvshows, BigshowTrendings } from "../customData";

import Slider from "./Components/Slider";

import Movies from "./Components/Movies";
import TopWebShows from "./Components/TopWebShows";

function App() {
  return (
    <>
      {/* <CustomCarousel/> */}
      <div id="main">
        <Slider />

        <Movies
          title="Trending Web Shows"
          faAngleRight={faAngleRight}
          series={series}
        />

        {/* <TrendingWebShow /> */}

        {/* MOVIES */}

        <TopWebShows
          title="Top Movies"
          faAngleRight={faAngleRight}
          series={movies}
        />

        {/* TVSHOWS */}

        <Movies
          title="Top TV Shows"
          faAngleRight={faAngleRight}
          series={tvshows}
        />

        {/*BigShow TRENDING */}

        <Movies
          title="BigShow Trending Shows"
          faAngleRight={faAngleRight}
          series={BigshowTrendings}
        />
      </div>
    </>
  );
}

export default App;
