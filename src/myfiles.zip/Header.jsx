import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { faBookmark } from "@fortawesome/free-solid-svg-icons";
import { faCircleUser } from "@fortawesome/free-solid-svg-icons";

const Header = () => {
  return (
    <>
      <header className="z-1">
        <div className="logo">
          <img src="logo.png" alt="" />
        </div>
        <input
          type="search"
          name="search"
          id="search_input"
          placeholder="Search Bigshow"
        />

        <nav>
          <ul className="nav-links">
            <li>
              <a href="#" className="nav-link">
                Home
              </a>
            </li>
            <li>
              <a href="#" className="nav-link">
                Movies
              </a>
            </li>
            <li>
              <a href="#" className="nav-link">
                Web-Shows
              </a>
            </li>
            <li>
              <a href="#" className="nav-link highlight">
                Watch List
                <FontAwesomeIcon icon={faBookmark} className="watchlist-icon" />
              </a>
            </li>
            <li>
              <a href="#" className="nav-link highlight">
                Sign In
                <FontAwesomeIcon icon={faCircleUser} className="signin-icon" />
              </a>
            </li>
          </ul>
        </nav>

        <div className="head-icons">
          <FontAwesomeIcon icon={faMagnifyingGlass} className="search_icon" />
          <img src="menu.png" alt="" className="menu-icon" />
        </div>
      </header>
    </>
  );
};

export default Header;
