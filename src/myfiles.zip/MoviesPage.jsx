import Header from "./Header";

const MoviesPage = () => {
  return (
    <>
      {/* <Header /> */}
      <div>Movies PAge</div>
    </>
  );
};

export default MoviesPage;
